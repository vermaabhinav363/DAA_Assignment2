#include <bits/stdc++.h>

using namespace std;

enum EDGE_TYPE {
    F,
    B
};

class Path{

private:

        vector<long long>vertices;

public:

        Path(vector<long long>vertices){
            this->vertices = vertices;
        }
        vector<long long> getVertices(){
            return this->vertices;
        }

};

class FlowGraph{

private:

        vector<long long>vertices;

        long long source;

        long long sink;

        map<pair<long long, long long>, long long> capacityLeft;

        map<pair<long long, long long>, long long> flow;

public:

        FlowGraph(long long source, long long sink, vector<long long>vertices, vector<tuple<long long, long long, long long> > adj[], long long size ){
            this->source = source;
            this->sink = sink;
            this->vertices = vertices;
            for (int i = 1; i < size; i++){
                for(auto j : adj[i]){
                    this->flow[make_pair(i,get<0>(j))]= get<1>(j);
                    this->capacityLeft[make_pair(i,get<0>(j))]= get<2>(j);
                }
            }
        }
        map<pair<long long, long long>, long long> getFlow(){
            return this->flow;
        }
        map<pair<long long, long long>, long long> getCapacityLeft(){
            return this->capacityLeft;
        }
        void setFlow( map<pair<long long, long long>, long long> flow){
            this->flow = flow;
            return ;
        }
        void setCapacityLeft( map<pair<long long, long long>, long long> capacityLeft ){
            this->capacityLeft = capacityLeft;
            return ;
        }
        long long getSource(){
            return this->source;
        }
        long long getSink(){
            return this->sink;
        }
        vector<long long> getVertices(){
            return this->vertices;
        }

};

class ResidualGraph{

private:

        vector<long long>vertices;

        long long source;

        long long sink;

        vector<tuple<long long, long long, EDGE_TYPE> > adj[1000];

        map<pair<long long, long long>, EDGE_TYPE> edgeType;

public:

        ResidualGraph(FlowGraph G1){
            this->source = G1.getSource();
            this->sink = G1.getSink();
            this->vertices = G1.getVertices();
            map<pair<long long, long long>, long long>flow =  G1.getFlow();
            map<pair<long long, long long>, long long>capacity =  G1.getCapacityLeft();
            this->edgeType.clear();
            for(auto m:flow){
                if(m.second!=0){
                this->edgeType[make_pair(m.first.second,m.first.first)]= B;
                this->adj[m.first.second].push_back(make_tuple(m.first.first,m.second,B));
                }
            }
            for(auto m:capacity){
                if(m.second!=0){
                this->edgeType[m.first]= F;
                this->adj[m.first.first].push_back(make_tuple(m.first.second,m.second,F));
                }
                else{
                this->adj[m.first.first].push_back(make_tuple(m.first.second,-1,F));
                }
            }

        }
        Path getAPath(){

            unordered_map<long long, long long> parent; // stores the parent of each node in the BFS traversal
            queue<long long> q; // queue for BFS traversal
            vector<bool> visited(this->vertices.size(), false); // visited set

            q.push(this->source);
            visited[this->source] = true;
            parent[this->source] = -1;

            while (!q.empty()) {
                long long curr_node = q.front();
                q.pop();
                if (curr_node == this->sink) {
                    // Print path from source to destination
                    vector<long long> vecx;
                    long long node = this->sink;
                    while (node != -1) {
                        vecx.push_back(node);
                        node = parent[node];
                    }
                    reverse(vecx.begin(),vecx.end());
                    Path path(vecx);
                    return path;
                }

                for (auto neighbor : this->adj[curr_node]) {
                    long long next_node = get<0>(neighbor);
                    long long isAvailable = get<1>(neighbor);
                    if (!visited[next_node] && isAvailable!=-1) {
                        q.push(next_node);
                        visited[next_node] = true;
                        parent[next_node] = curr_node;
                    }
                }
            }
            vector<long long> vecx;
            Path path(vecx);
            return path;
        }

        map<pair<long long, long long>, EDGE_TYPE> getEdgeType(){
            return this->edgeType;
        }


};

class Auxiliary{

public:

      static void augment(Path path, FlowGraph& G1, ResidualGraph& G2){
         long long b = findBottleNeck(path, G1, G2);
         vector<long long> vertices = path.getVertices();
         map<pair<long long, long long>, EDGE_TYPE> edgeTpe =  G2.getEdgeType();
         map<pair<long long, long long>, long long> flow = G1.getFlow();
         map<pair<long long, long long>, long long> capacity = G1.getCapacityLeft();
         for(long long i = 1 ; i < vertices.size() ; i++){
             if(edgeTpe[make_pair(vertices[i-1],vertices[i])]==F){
                flow[make_pair(vertices[i-1],vertices[i])]+=b;
                if(capacity[make_pair(vertices[i-1],vertices[i])]-b!=0){
                capacity[make_pair(vertices[i-1],vertices[i])]-=b;
                }
                else{
                capacity.erase(make_pair(vertices[i-1],vertices[i]));
                }
             }
             else{
                if(flow[make_pair(vertices[i],vertices[i-1])]-b!=0){
                flow[make_pair(vertices[i],vertices[i-1])]-=b;
                }
                else{
                flow.erase(make_pair(vertices[i],vertices[i-1]));
                }
                capacity[make_pair(vertices[i],vertices[i-1])]+=b;
             }
         }
         G1.setFlow(flow);
         G1.setCapacityLeft(capacity);
         return ;
      }

      static long long findBottleNeck(Path path, FlowGraph G1, ResidualGraph G2){
         map<pair<long long, long long>, EDGE_TYPE> edgeType =  G2.getEdgeType();
         map<pair<long long, long long>, long long> capacityLeft = G1.getCapacityLeft();
         map<pair<long long, long long>, long long> flow = G1.getFlow();
         long long bottleNeck = INT_MAX;
         vector<long long> vertices = path.getVertices();
         for(long long i = 1 ; i < vertices.size() ; i++){
                if (edgeType.find(make_pair(vertices[i-1],vertices[i])) != edgeType.end()) {
                    EDGE_TYPE currentEdgeType = edgeType[make_pair(vertices[i-1],vertices[i])];
                    if(currentEdgeType == F){
                        bottleNeck=min(bottleNeck, capacityLeft[make_pair(vertices[i-1],vertices[i])]);
                    }
                    else{
                        bottleNeck=min(bottleNeck, flow[make_pair(vertices[i],vertices[i-1])]);
                    }
                }
                else{
                    EDGE_TYPE currentEdgeType = edgeType[make_pair(vertices[i],vertices[i-1])];
                    if(currentEdgeType == F){
                        bottleNeck=min(bottleNeck, capacityLeft[make_pair(vertices[i],vertices[i-1])]);
                    }
                    else{
                        bottleNeck=min(bottleNeck, flow[make_pair(vertices[i],vertices[i-1])]);
                    }
                }

         }
         return bottleNeck;
      }

};

class NetworkFlow{

public:
     static FlowGraph FordFulkerson(FlowGraph G1,ResidualGraph G2){
        while(1){
        Path path = G2.getAPath();
        if(path.getVertices().size()==0)
            goto c;

        Auxiliary::augment(path,G1,G2);
        ResidualGraph G3(G1);
        G2 = G3;
        }
        c:;
        return G1;
     }


};
class stCut{

       map<long long, long long> edges;

       vector<long long>verticesReachable;

       vector<long long>verticesNotReachable;

public:

       void min_stCut(map<pair<long long, long long>, long long> capacity,long long source, long long size,map<long long, long long>edges){
            map< long long, vector<long long> > adj;
            for(auto m : capacity){
                adj[m.first.first].push_back(m.first.second);
            }
            map<long long, bool> visited;
            queue<long long>q;
            q.push(source);
            visited[source]=true;
            while(q.size()!=0){
               long long el = q.front();
               this->verticesReachable.push_back(el);
               q.pop();
               for(auto i : adj[el]){
                    if(!visited[i]){
                        visited[i]=true;
                        q.push(i);
                    }
               }
            }
            for(long long i = 1 ;i<=size;i++){
                if(!visited[i]){
                    this->verticesNotReachable.push_back(i);
                }
            }


       cout<<"\nNodes reachable from source :: \n\n";
       for(long long i = 0 ; i < this->verticesReachable.size() ; i++){
            cout<<this->verticesReachable[i]<<" ";
       }
       cout<<"\n\n";
       cout<<"Nodes not reachable from source :: \n\n";
       for(long long i = 0 ; i < this->verticesNotReachable.size() ; i++){
            cout<<this->verticesNotReachable[i]<<" ";
       }
       cout<<"\n\n";
       cout<<"Minimum st cut::\n\n";
       for(auto m : edges){
            auto it1 = std::find(this->verticesReachable.begin(), this->verticesReachable.end(), m.first);

            if (it1 != this->verticesReachable.end()) {
                auto it2 = std::find(this->verticesNotReachable.begin(), this->verticesNotReachable.end(), m.second);

                if(it2 != this->verticesNotReachable.end()){
                    cout<<m.first<<" "<<m.second<<"\n";
                }
            }

       }
       cout<<"\n";
    }


};

int main()
{
    vector<long long>vertices;
    for(long long i = 0 ;i < 12;i++)
        vertices.push_back(i+1);
    vector<tuple<long long, long long, long long> > adjFlow[12];
    adjFlow[11].push_back(make_tuple(1,0,1));
    adjFlow[11].push_back(make_tuple(2,0,1));
    adjFlow[11].push_back(make_tuple(3,0,1));
    adjFlow[11].push_back(make_tuple(4,0,1));
    adjFlow[11].push_back(make_tuple(5,0,1));
    adjFlow[1].push_back(make_tuple(6,0,1));
    adjFlow[2].push_back(make_tuple(6,0,1));
    adjFlow[3].push_back(make_tuple(7,0,1));
    adjFlow[4].push_back(make_tuple(8,0,1));
    adjFlow[5].push_back(make_tuple(10,0,1));
    adjFlow[6].push_back(make_tuple(12,0,1));
    adjFlow[7].push_back(make_tuple(12,0,1));
    adjFlow[8].push_back(make_tuple(12,0,1));
    adjFlow[9].push_back(make_tuple(12,0,1));
    adjFlow[10].push_back(make_tuple(12,0,1));
    adjFlow[1].push_back(make_tuple(7,0,1));
    adjFlow[3].push_back(make_tuple(8,0,1));
    adjFlow[4].push_back(make_tuple(9,0,1));
    adjFlow[4].push_back(make_tuple(10,0,1));

    vector<tuple<long long, long long, EDGE_TYPE > > adjResidual[8];
    adjResidual[1].push_back(make_tuple(7,2,F));
    adjResidual[1].push_back(make_tuple(8,4,F));
    adjResidual[2].push_back(make_tuple(3,5,F));
    adjResidual[2].push_back(make_tuple(1,3,F));
    adjResidual[2].push_back(make_tuple(4,2,F));
    adjResidual[3].push_back(make_tuple(4,3,F));
    adjResidual[3].push_back(make_tuple(5,4,F));
    adjResidual[4].push_back(make_tuple(6,4,F));
    adjResidual[6].push_back(make_tuple(5,2,F));
    adjResidual[6].push_back(make_tuple(8,3,F));
    adjResidual[5].push_back(make_tuple(1,5,F));
    adjResidual[7].push_back(make_tuple(5,2,F));
    adjResidual[7].push_back(make_tuple(8,3,F));
    //source = 2
    //sink = 8
    //assumption :: vertices have to be given in an order from 1 to N, inclusive both, size is N

    FlowGraph G1(11,12,vertices,adjFlow,12);
    ResidualGraph G2(G1);
    G1 = NetworkFlow::FordFulkerson(G1,G2);
    map<pair<long long, long long>, EDGE_TYPE> edgeType =  G2.getEdgeType();
    map<long long, long long>edges;
    for(auto m : edgeType){
        edges[m.first.first]=m.first.second;
    }
    map<pair<long long, long long>, long long> flow =  G1.getFlow();
    map<pair<long long, long long>, long long> capacity =  G1.getCapacityLeft();
    cout<<"FLOW GOING::\n";
    for(auto m:flow){
        cout<<m.first.first<<" "<<m.first.second<<" "<<m.second<<"\n";
    }
    cout<<"\n";
    cout<<"CAPACITY LEFT::\n";
    for(auto m:capacity){
        cout<<m.first.first<<" "<<m.first.second<<" "<<m.second<<"\n";
    }
    stCut st;
    st.min_stCut(capacity,2,8,edges);

    vector<long long>verticesBipart;
    for(long long i = 0 ;i < 2;i++)
        verticesBipart.push_back(i+1);

    vector<tuple<long long, long long, long long> > adjFlowBipart[8];
    adjFlowBipart[1].push_back(make_tuple(7,0,1));
    adjFlowBipart[1].push_back(make_tuple(8,0,1));
    adjFlowBipart[2].push_back(make_tuple(3,0,1));
    adjFlowBipart[2].push_back(make_tuple(1,0,1));
    adjFlowBipart[2].push_back(make_tuple(4,0,1));
    adjFlowBipart[3].push_back(make_tuple(4,0,1));
    adjFlowBipart[3].push_back(make_tuple(5,0,1));
    adjFlowBipart[4].push_back(make_tuple(6,0,1));
    adjFlowBipart[6].push_back(make_tuple(5,0,1));
    adjFlowBipart[6].push_back(make_tuple(8,0,1));
    adjFlowBipart[5].push_back(make_tuple(1,0,1));
    adjFlowBipart[7].push_back(make_tuple(5,0,1));
    adjFlowBipart[7].push_back(make_tuple(8,0,1));

    vector<tuple<long long, long long, EDGE_TYPE > > adjResidualBipart[8];
    adjResidualBipart[1].push_back(make_tuple(7,1,F));
    adjResidualBipart[1].push_back(make_tuple(8,1,F));
    adjResidualBipart[2].push_back(make_tuple(3,1,F));
    adjResidualBipart[2].push_back(make_tuple(1,1,F));
    adjResidualBipart[2].push_back(make_tuple(4,1,F));
    adjResidualBipart[3].push_back(make_tuple(4,1,F));
    adjResidualBipart[3].push_back(make_tuple(5,1,F));
    adjResidualBipart[4].push_back(make_tuple(6,1,F));
    adjResidualBipart[6].push_back(make_tuple(5,1,F));
    adjResidualBipart[6].push_back(make_tuple(8,1,F));
    adjResidualBipart[5].push_back(make_tuple(1,1,F));
    adjResidualBipart[7].push_back(make_tuple(5,1,F));
    adjResidualBipart[7].push_back(make_tuple(8,1,F));


    FlowGraph G3(2,8,verticesBipart,adjFlowBipart,8);

    ResidualGraph G4(G3);



    G3 = NetworkFlow::FordFulkerson(G3,G4);
    map<pair<long long, long long>, long long> flowBipartite =  G3.getFlow();
    long long bipartite = 0;
    for(auto m : flowBipartite){
        if(m.first.first==2){
            bipartite+= m.second;
        }
    }
    cout<<"Maximum number of edges that can be added to the bipartite graph:: ";
    cout<<bipartite<<"\n";
}
