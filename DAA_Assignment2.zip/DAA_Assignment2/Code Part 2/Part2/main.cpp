/*! \mainpage Segmented Least Squares Algorithm (Line Fitting Dynamic Programming Algorithm)
 *
 * ABHINAV TYAGI 2020A7PS2043H
 *
 * DHRUV MERCHANT 2020A7PS2063H
 *
 * RITVIK 2020A7PS1723H
 *
 * UDAY SINGH THAKUR 2020A7PS2050H
 *
 */

#include <bits/stdc++.h>
using namespace std;

class G_edge;
class Graph;
class Residual_Graph;
class Residual_Edge;
class BFS_path;

/// The G_edge class represents an edge in the graph used in the Ford-Fulkerson algorithm
class G_edge{
    public:

        /**
        *@brief Constructor that initializes the G_edge object with the terminal node and capacity
        *@param node The terminal node of the edge
        *@param capacity The capacity of the edge
        */

        G_edge(long long int node, double capacity);

        long long int terminal_node;
        double flow;
        double capacity;
};

G_edge :: G_edge(long long int terminal_node, double capacity){
    this->terminal_node = terminal_node;
    this->capacity = capacity;
    flow = 0.0;
}

/// The Graph Class
class Graph{
    public:
        map<long long int,vector<G_edge*>> adjacency_list;
        long long int nodes;

        void printGraph();
};

 /**
 * @brief The Residual Graph class represents the residual graph used in the Ford-Fulkerson algorithm for solving the maximum flow problem
 */

class Residual_Graph{
    public:
        map<long long int,vector<Residual_Edge*>> adjacency_list;
        long long int nodes;

        void printGraph();
};

/**
 * @brief The Residual Edge class represents an edge in the residual graph used in the Ford-Fulkerson algorithm for solving the maximum flow problem
 */

class Residual_Edge{
    public:

    /**
     * @brief Constructs a Residual_Edge object.
     * @param terminal The terminal node of the residual edge.
     * @param fwd A boolean value indicating whether the residual edge is a forward edge or a backward edge.
     * @param weight The weight or capacity of the residual edge.
     */

        Residual_Edge(long long terminal, bool fwd, double weight);

        long long int terminal_node;
        bool forward_edge = true;
        double weight;
};

Residual_Edge :: Residual_Edge(long long terminal, bool fwd, double weight){
    terminal_node = terminal;
    this->weight = weight;
    forward_edge = fwd;
}

/**
 * @brief The BFS Path class represents a path found by the Breadth-First Search algorithm
 */

class BFS_path{
    public:
        bool isPossible;
        vector<long long int> path;
        double bottleneck;
};

void Graph :: printGraph(){
    for (auto& node : adjacency_list) {
            for (auto& neighbor : node.second) {
                cout << node.first << "->" << neighbor->terminal_node;
            }
            cout << "\n\n";

        }
}

void Residual_Graph :: printGraph(){
    for (auto& node : adjacency_list) {
            for (auto& neighbor : node.second) {
                cout << node.first << "->" << neighbor->terminal_node;
            }
            cout << "\n\n";
        }
}

/**
 * @brief Calculates the maximum flow in the network using the Ford-Fulkerson algorithm
 * @param source The source node of the network
 * @param G The graph represented as an adjacency list of G_edge pointers
 * @return The maximum flow in the network
 */

double calculateFlow(long long int source, map<long long int,vector<G_edge*>>&G){

    double flow = 0;
    for(auto v: G[source]){
        flow += v->flow;
    }
    // cout<<"value of flow: "<<flow<<"\n\n";
    return flow;
}

/**
 * @brief Finds a path from the source to the sink in the residual graph and returns the path and its bottleneck capacity
 * @param parent A map containing the parent node and edge of each node in the Breadth-First Search tree
 * @param sink The sink node of the network
 * @return A pair containing the path from the source to the sink and its bottleneck capacity
 */

pair<vector<long long int>, double> path_and_bottleneck (map<long long int, pair<long long int, double>> &parent, long long int sink){
    vector<long long int> path;
    path.push_back(sink);
    double bottleneck = INT_MAX;
    long long int prev = parent[sink].first;
    bottleneck = parent[sink].second;

    while(prev != -1){
        path.push_back(prev);
        bottleneck = min(bottleneck,parent[prev].second);
        prev = parent[prev].first;
    }

    reverse(path.begin(),path.end());
    return {path, bottleneck};
}

/**
 * @brief Finds a path from the source to the sink in the residual graph using Breadth-First Search and returns the path and its bottleneck capacity
 * @param source The source node of the network
 * @param sink The sink node of the network
 * @param G The original graph represented as an adjacency list of G_edge pointers
 * @param Gf The residual graph represented as an adjacency list of Residual_Edge pointers
 * @param n The number of nodes in the network
 * @return A BFS_path object containing the path from the source to the sink, its bottleneck capacity, and a boolean flag indicating if a path was found
 */

BFS_path BFS_checkpath(long long int source,long long int sink, map<long long int,vector<G_edge*>>&G,map<long long int,vector<Residual_Edge*>>&Gf, long long int n){

    vector<bool>visited(n,false);
    map<long long int, pair<long long int,double>> parent; // parent,child combination

    parent[source] = {-1,INT_MAX};
    queue<long long int>bfs_queue;

    bfs_queue.push(source);
    visited[source] = true;

    while(!bfs_queue.empty()){
        long long int current_node = bfs_queue.front();
        bfs_queue.pop();
        for(auto v: Gf[current_node]){
            if(v->weight > 0 && visited[v->terminal_node] == false){
                bfs_queue.push(v->terminal_node);
                visited[v->terminal_node] = true;
                parent[v->terminal_node] = {current_node, v->weight};
            }
        }

    }
    BFS_path result;

    if(visited[sink] == true){
        result.isPossible = true;
        result.path = path_and_bottleneck(parent,sink).first;
        result.bottleneck = path_and_bottleneck(parent,sink).second;


        // for(auto x: result.path){
            // cout<<x<<" ";
        // }
        // cout<<"\n\n";
        return result;
    }

    result.isPossible = false;
    result.path = {};
    return result;
}

/**
 * @brief Given a path in the residual graph represented as a vector of node indices, returns a vector of Residual_Edge pointers that represent the edges of the path in the residual graph
 * @param path A vector of node indices representing a path in the residual graph
 * @param Gf The residual graph represented as an adjacency list of Residual_Edge pointers
 * @return A vector of Residual_Edge pointers that represent the edges of the path in the residual graph
 */

vector<Residual_Edge*> residualPath(vector<long long int>&path,map<long long int,vector<Residual_Edge*>>&Gf){
    vector<Residual_Edge*>residual_path;
    long long int n = path.size();

    for(int i = 0 ; i < n-1; i++){

        long long int src = path[i];
        long long int dest = path[i+1];

        for(auto x: Gf[src]){
            if(x->terminal_node == dest){
                residual_path.push_back(x); //path without origin
            }
        }

    }
    // cout<<"Residual path: node,wt,fwd\n";
    // for(auto x: residual_path){
        // cout<<x->terminal_node<<"\t "<<x->weight<<" \t"<<x->forward_edge<<"\n";
    // }
    // cout<<"\n\n";
    return residual_path;
}

/**
 * @brief Given a residual path, a flow network, a bottleneck value, and the original path, augments the flow on the edges of the flow network and updates the residual graph
 * @param rpath A vector of Residual_Edge pointers representing a path in the residual graph
 * @param G The flow network represented as an adjacency list of G_edge pointers
 * @param bottleneck The bottleneck value for the given path in the residual graph
 * @param path A vector of node indices representing the original path in the flow network
 */

void augment(vector<Residual_Edge*>&rpath, map<long long int,vector<G_edge*>>&G,double bottleneck,vector<long long int>&path){

    long long int n = rpath.size();
    for(int i = 0 ; i < n ; i++){
        if(rpath[i]->forward_edge == true){
            long long int v = rpath[i]->terminal_node;
            long long int u = path[i];
            for(auto x: G[u]){
                if(x->terminal_node == v){
                    // cout<<"From: "<<u<<"To: "<<v<<" flow = "<<x->flow<<endl;
                    x->flow += bottleneck;
                    // cout<<"new flow: "<<x->flow<<endl;
                }
            }
        }

        else if(rpath[i]->forward_edge == false){
            long long int v = rpath[i]->terminal_node;
            long long int u = path[i];
            for(auto x: G[v]){
                if(x->terminal_node == u){
                    // cout<<"From: "<<u<<"To: "<<v<<" flow = "<<x->flow<<endl;
                    x->flow -= bottleneck;
                    // cout<<"new flow: "<<x->flow<<endl;
                }
            }
        }
    }
}

/**
 * @brief Given a flow network G, its residual graph Gf, the number of nodes n, and the source node index, updates Gf based on the current flow in G
 * @param G The flow network represented as an adjacency list of G_edge pointers
 * @param Gf The residual graph represented as an adjacency list of Residual_Edge pointers
 * @param n The number of nodes in the flow network
 * @param source The index of the source node in the flow network
 */

void updateGf(map<long long int,vector<G_edge*>>&G,map<long long int,vector<Residual_Edge*>>&Gf,long long int n,long long int source){

    Gf.clear();
    for(auto x:G){
        for(auto v:x.second){
            Residual_Edge* res = new Residual_Edge({v->terminal_node,true,(v->capacity - v->flow)});
            Gf[x.first].push_back(res);

            Residual_Edge* back = new Residual_Edge({x.first,false,v->flow});
            Gf[v->terminal_node].push_back(back);

        }
    }

}
void printG(map<long long int,vector<G_edge*>>&G){

    for(auto x: G){
        for(auto v:x.second){
            cout<<x.first<<" "<<v->terminal_node<<" "<<v->flow<<" "<<v->capacity<<endl;
        }
    }
    cout<<"\n";
}
void printGf(map<long long int,vector<Residual_Edge*>>&Gf){

    for(auto x: Gf){
        for(auto v:x.second){
            cout<<x.first<<" "<<v->terminal_node<<" "<<v->weight<<" "<<v->forward_edge<<endl;
        }
    }
    cout<<"\n";

}

/**
 * @brief Ford_Fulkerson Algorithm
 * @param G The flow network represented as an adjacency list of G_edge pointers
 * @param Gf The residual graph represented as an adjacency list of Residual_Edge pointers
 * @param n The number of nodes in the flow network
 * @param source The index of the source node in the flow network
 * @param sink The sink node of the network
 * @return the Maximum flow
 */

double Ford_Fulkerson(map<long long int,vector<G_edge*>>&G,map<long long int,vector<Residual_Edge*>>&Gf,long long int source,long long int sink, long long int n){

    double value = calculateFlow(source,G);
    while(1){
        BFS_path result = BFS_checkpath(source,sink,G,Gf,n);
        bool isPath = result.isPossible;

        if(isPath){
            vector<long long int> flow_path;
            flow_path = result.path;
            double bottleneck = result.bottleneck;

            vector<Residual_Edge*>residual_path = residualPath(flow_path,Gf);

            augment(residual_path,G,bottleneck,flow_path);
            // printG(G);
            updateGf(G,Gf,n,source);
            // printGf(Gf);
            value = calculateFlow(source,G);
            // cout<<"\n\n\n\n;

        }
        else{
            break;
        }
    }
    return value;
}

/**
 * @brief This function finds the minimum s-t cut of a graph using the Ford-Fulkerson algorithm
 * @param G The flow network represented as an adjacency list of G_edge pointers
 * @param Gf The residual graph represented as an adjacency list of Residual_Edge pointers
 * @param n The number of nodes in the flow network
 * @param source The index of the source node in the flow network
 * @param sink The sink node of the network
 * @param nodes The list of nodes in the graph
 */

void min_st_cut(map<long long int,vector<G_edge*>>&G,map<long long int,vector<Residual_Edge*>>&Gf,long long int source, long long int sink, long long int n,vector<long long int>nodes){

    vector<long long int> source_list;
    vector<long long int> dest_list;

    vector<bool>visited(n,false);

    queue<long long int>bfs_queue;

    bfs_queue.push(source);
    visited[source] = true;
    source_list.push_back(source);

    while(!bfs_queue.empty()){
        long long int current_node = bfs_queue.front();
        bfs_queue.pop();
        for(auto v: Gf[current_node]){
            if(v->weight > 0 && visited[v->terminal_node] == false){
                bfs_queue.push(v->terminal_node);
                visited[v->terminal_node] = true;
                source_list.push_back(v->terminal_node);
            }
        }
    }

     for (int i = 0; i < nodes.size(); i++)
    {
        int j;
        for (j = 0; j < source_list.size(); j++)
            if (nodes[i] == source_list[j])
                break;

        if (j == source_list.size())
            dest_list.push_back(nodes[i]);
    }

    for(auto x: source_list){
        cout<<x<<endl;
    }
    cout<<endl;
    for(auto x: dest_list){
        cout<<x<<endl;
    }
    cout<<endl;

}


int main(){

    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    long long int n;
    cin>>n;
    long long int e;
    cin>>e;

    long long src;
    long long dest;
    cin>> src>>dest;

    set<long long int>all_nodes;

    Graph* graph = new Graph();
    Residual_Graph* rgraph = new Residual_Graph();
    while(e--){
        long long x,y;
        double w;
        cin>>x>>y>>w;

        G_edge* g = new G_edge(y,w);
        Residual_Edge* rg = new Residual_Edge(y,true,w);
        graph->adjacency_list[x].push_back(g);
        rgraph->adjacency_list[x].push_back(rg);

        all_nodes.insert(x);
        all_nodes.insert(y);

    }

    vector<long long int> all_nodes_vector(all_nodes.begin(),all_nodes.end());

    graph->nodes = n;
    rgraph->nodes = n;


    //  for(auto x: graph->adjacency_list){
        // for(auto v:x.second){
            // cout<<"from :"<<x.first<<" to:"<<v->terminal_node<<" "<<v->flow<<" "<<v->capacity<<endl;
        // }
    // }
    // cout<<endl;
    double ans = Ford_Fulkerson(graph->adjacency_list,rgraph->adjacency_list,src,dest,n);

    printG(graph->adjacency_list);

    printGf(rgraph->adjacency_list);

    min_st_cut(graph->adjacency_list,rgraph->adjacency_list,src,dest,n, all_nodes_vector);
    // cout<<"\n\n";
    for(auto x: graph->adjacency_list[src]){
        cout<<src<<" "<<x->terminal_node<<" ";
        cout<<x->flow<<endl;
    }
    cout<<endl;

    cout<<ans<<endl;
    cout<<endl;
    // cout<<"////////////////////////////////////"<<endl;

    long long int n_bipartite;
    cin>>n_bipartite;


    long long int e_bipartite;
    cin>>e_bipartite;


    set<long long int>all_nodes_bipartite;

    Graph* graph_bipartite = new Graph();
    Residual_Graph* rgraph_bipartite = new Residual_Graph();

    long long int src_bip = n_bipartite;
    long long int dest_bip = n_bipartite + 1;

    all_nodes_bipartite.insert(src_bip);
    all_nodes_bipartite.insert(dest_bip);

    set<long long int>A_bip;
    set<long long  int>B_bip;

    while(e_bipartite--){
        long long x_bipartite,y_bipartite;
        cin>>x_bipartite>>y_bipartite;

        G_edge* g = new G_edge(y_bipartite,1);
        Residual_Edge* rg = new Residual_Edge(y_bipartite,true,1);

        if(A_bip.find(x_bipartite) == A_bip.end()){
            G_edge* g_src = new G_edge(x_bipartite,1);
            Residual_Edge* rg_src = new Residual_Edge(x_bipartite,true,1);

            graph_bipartite->adjacency_list[src_bip].push_back(g_src);
            rgraph_bipartite->adjacency_list[src_bip].push_back(rg_src);

        }

    if(B_bip.find(y_bipartite) == B_bip.end()){
        G_edge* g_dest = new G_edge(dest_bip,1);
        Residual_Edge* rg_dest = new Residual_Edge(dest_bip,true,1);

        graph_bipartite->adjacency_list[y_bipartite].push_back(g_dest);
        rgraph_bipartite->adjacency_list[y_bipartite].push_back(rg_dest);

    }
        graph_bipartite->adjacency_list[x_bipartite].push_back(g);
        rgraph_bipartite->adjacency_list[x_bipartite].push_back(rg);

        A_bip.insert(x_bipartite);
        B_bip.insert(y_bipartite);

        all_nodes_bipartite.insert(x_bipartite);
        all_nodes_bipartite.insert(y_bipartite);
    }
    graph_bipartite->nodes = n_bipartite;
    rgraph_bipartite->nodes = n_bipartite;

    vector<long long int> all_nodes_bipartite_vector(all_nodes_bipartite.begin(),all_nodes_bipartite.end());

    double ans_bipartite = Ford_Fulkerson(graph_bipartite->adjacency_list,rgraph_bipartite->adjacency_list,src_bip,dest_bip,n_bipartite);

    for(auto x: A_bip){
        cout<<x<<endl;
    }
    cout<<endl;

        for(auto x: B_bip){
        cout<<x<<endl;
    }
    cout<<endl;

    cout<<src_bip<<endl;
    cout<<endl;
    cout<<dest_bip<<endl;
    cout<<endl;

    printG(graph_bipartite->adjacency_list);
    printGf(rgraph_bipartite->adjacency_list);
    min_st_cut(graph_bipartite->adjacency_list,rgraph_bipartite->adjacency_list,src_bip,dest_bip,n_bipartite, all_nodes_bipartite_vector);
    for(auto x: graph_bipartite->adjacency_list[src_bip]){
        cout<<src_bip<<" "<<x->terminal_node<<" ";
        cout<<x->flow<<endl;
    }
    cout<<endl;
    cout<<ans_bipartite;

    return 0;

}
